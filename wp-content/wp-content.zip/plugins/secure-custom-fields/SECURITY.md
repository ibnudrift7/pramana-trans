# Reporting Security Issues

The WordPress community take security bugs seriously. We appreciate your efforts to disclose your findings responsibly and will make every effort to acknowledge your contributions.

To report a security issue, please visit the [WordPress HackerOne](https://hackerone.com/wordpress) program.
